http://bootstrapdocs.com/v2.0.4/docs/base-css.html


Want to attach a datepicker to all inputs with class .datepicker ?

<script>
  $(".datepicker").each(function() {
    $( this ).datepicker({format: 'dd-mm-yyyy', setDate: new Date()});
  });
</script>