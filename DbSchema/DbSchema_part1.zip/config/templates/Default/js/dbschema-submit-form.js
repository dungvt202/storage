/* SEARCH IN A DOCUMENT ALL INPUT FIELDS WITH CLASS STARTING WITH 'CLS'.
 IF THE CLASS NAME IS A SUBSTRING OF path ADD THE INPUT FIELD TO A VIRTUAL FORM.
 THE VIRTUAL FORM CAN BE SENT TO url TARGET FORM AND OPENED AS DIALOG or IN THE SAME WINDOW.
 */

function createVirtualForm( url, path, variables ) {
    showPreloader();
    var virtualForm = $('<form />').hide();
    virtualForm.attr('action', url ).attr('method', 'POST').attr('enctype','multipart/form-data');
    var itemNames = [];

    var isNameUnique = function(newName){
        for(var i=0; i<itemNames.length; i++) {
            if (itemNames[i] === newName) return false;
        }
        itemNames.push(newName);
        return true;
    };

    var addParameterToVirtualForm = function(paramName, paramValue){
        if ( isNameUnique( paramName )){
            var input = $('<input type="hidden">');
            input.attr({ 'id':     paramName,
                'name':   paramName,
                'value':  paramValue });
            virtualForm.append(input);
        }
    };

    var addVariablesToVirtualForm = function() {
        var urlSplit = decodeURI(variables).split("&");
        for(var i=0;i<urlSplit.length;i++){
            var urlPair = urlSplit[i].split("=");
            addParameterToVirtualForm(urlPair[0], urlPair[1] );
        }
    };

    var addInputFieldToVirtualForm = function( input ){
        var cls = input.attr('class');
        var blankIdx = cls.indexOf(" ");
        if ( blankIdx > 0 ) cls = cls.substring( 0, blankIdx );
        var name = input.attr('name');
        if ( path === cls || path.lastIndexOf( cls ) == 0 ) {
            if ( input.attr('type')=="radio" || input.attr('type')=="checkbox"){
                addParameterToVirtualForm(name, input.prop('checked') );
            } else {
                addParameterToVirtualForm(name, input.val() );
            }
        }
    };

    var showDebugFormAlert = function(){
        var debug = "######## DEBUG INFORMATION ########\n\n";
        debug += "-------- VARIABLES FROM INPUT FIELDS --------\n";
        $(":input[class][name]").each(function() {
            var input = $(this);
            var cls = input.attr('class');
            var blankIdx = cls.indexOf(" ");
            if ( blankIdx > 0 ) cls = cls.substring( 0, blankIdx );
            var name = input.attr('name');
            if ( path === cls || path.lastIndexOf( cls ) == 0 ) {
                if ( input.attr('type')=="radio" || input.attr('type')=="checkbox"){
                    debug+= name + '=' + input.prop('checked') + "\n";
                } else {
                    debug+= name + '=' + input.val() + "\n";
                }
            }
        });
        debug += "\n-------- VARIABLES DEFINED IN FORM --------\n";
        var urlSplit = decodeURI(variables).split("&");
        for(var i=0;i<urlSplit.length;i++){
            debug+= urlSplit[i] + "\n";
        }
        alert( debug );
    };

    if ( variables != null && variables.indexOf("debug=true")>-1){
        showDebugFormAlert();
    }
    $(":input[class][name]").each(function() {
        addInputFieldToVirtualForm( $(this) );
    });
    addVariablesToVirtualForm();

    return virtualForm;
}


function openFormInDialog( url, title, path, variables){
    var form = createVirtualForm( url, path, variables );
    $.ajax({
        type: form.attr('method'),
        url: form.attr('action'),
        data: form.serialize(),
        success: function (data) {
            // IF WE OPEN A MODAL FROM A MODAL REUSE THE SAME MODAL
            if( $( "#dbs_modal" ).length ){
                hidePreloader();
                $( "#dbs_modal" ).find('.modal-body').html(data);
            } else {
                hidePreloader();
                // OPEN A NEW MODAL
                BootstrapDialog.show({
                    id:'dbs_modal',
                    title : title,
                    message: $(data)
                });
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            hidePreloader();
            alert( errorThrown + "\nStatus: " + textStatus);
        }
    });
}

function openForm( url, title, path, variables){
    var form = createVirtualForm( url, path, variables );
    form.appendTo( document.body);
    form.submit();
    form.remove();
}

function openFormInNewWindow( url, title, path, variables){
    var form = createVirtualForm( url, path, variables );
    form.attr('onSubmit', "window.open('about:blank', '" + url + "', '');action='" + url + "';target='" + url + "';");
    form.appendTo( document.body);
    hidePreloader();
    form.submit();
    form.remove();
}


function showPreloader(){
    $('body').css({'overflow':'hidden'});
    $('#preloader').fadeIn('slow'); // will fade out the white DIV that covers the website.
    $('#status').fadeIn('slow'); // will first fade out the loading animation
}

function hidePreloader(){
    $('#status').fadeOut('slow'); // will first fade out the loading animation
    $('#preloader').fadeOut('slow'); // will fade out the white DIV that covers the website.
    $('body').css({'overflow':'visible'});
}



/*
 function formerSubmitToWindow( url, popupOrClose, classPath, extraVariables ) {

 // http://stackoverflow.com/questions/133925/javascript-post-request-like-a-form-submit
 var form = createForm( url, classPath, extraVariables );
 if ( popupOrClose == 'popup'){
 // WE USE URL FOR THE WINDOW NAME AS WELL AS FOR THE ACTION
 form.attr('onSubmit',
 "window.open('about:blank', '" + url + "', 'top=100,left=100,width=500,height=400,location=no,menubar=no,status=no,scrollbars=no');" +
 "action='" + url + "';" +
 "target='" + url + "';");
 } else {
 form.attr('action', url ).attr('method', 'POST');
 }
 if ( popupOrClose == 'close') {
 $.ajax({
 type: form.attr('method'),
 url: form.attr('action'),
 data: form.serialize()
 }).done(function() {
 window.opener.location.reload(true);
 window.close();
 }).fail(function() {
 });
 } else {
 form.appendTo( document.body);
 form.submit();
 form.remove();
 }
 }

 */




/*
 http://stackoverflow.com/questions/23402189/ajax-set-content-from-post-call/23465973#23465973

 // THIS WORKS FINE BUT GENERATES NO ENTRY IN HISTORY
 // COLLECT ALL INPUT FIELDS HAVING A CLASS AND NAME INTO THE USER OBJECT
 // SELECTED ARE ONLY THE INPUT FIELDS HAVING A CLASS STARTING WITH $path
 var user = new Object();

 // INCLUDE IN USER OBJECT ALL VARIALBES FROM urlVariables
 var urlSplit = urlVariables.split("&");
 for(var i=0;i<urlSplit.length;i++){
 var urlPair = urlSplit[i].split("=");
 user[urlPair[0]]=urlPair[1];
 }

 $("input[class][name]").each(function() {
 var cls = $(this).attr('class');
 var name = $(this).attr('name');
 if ( path.lastIndexOf( cls ) == 0 ) {
 user[name] = $(this).val();
 }
 });
 var userAsJson = JSON.stringify(user);

 $.ajax({
 type: "POST",
 url: "/sakila.EditActor",
 data: userAsJson,
 success: function(response){
 $(document.documentElement).html(response);
 //$(document.documentElement).innerHTML( response.responseText );
 }
 });
 */
