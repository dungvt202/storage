
$("[refresh_interval][refresh_url]").each(
    function() {
   var rInterval = $(this).attr('refresh_interval');
   var rUrl = $(this).attr('refresh_url');
   var elem = $(this);
   setInterval(
       function() {
           try {
               elem.load( rUrl );
           } catch ( err ){
               alert( err.toString() );
           }
       }, rInterval );
  }
);