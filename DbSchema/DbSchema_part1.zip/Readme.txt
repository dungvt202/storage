DbSchema - README

DbSchema is an universal database tool for designing and querying databases. Using DbSchema you can reverse engineer the
database schema from database and build multiple diagrams out of it. Directly in the diagrams you can edit the schema and
later Commit the changes on the database.
Using the Relational Data Browse you can explore the database data just per drag & drop. Multiple features like filtering,
sorting, instant editing will help you to interact with the data.
With the SQL editor you can edit and execute queries, scripts, do explain plan and others.
You can also use the Query Builder for visually building SQL queries and executing them.

Contents:
=========
  config/             Configuration templates files for different databases.
  drivers/            JDBC drivers. Drivers can be uploaded directly from the application and will be placed in this directory.
                      You can remove drivers by simply deleting them out of this directory.
  lib/                Application Java libraries
  log/                Application logs
  samples/            Sample schemas

Installing DbSchema
========================
DbSchema can run on Windows, Linux ( all versions ) and Mac OS.
YOU NEED JAVA RUNTIME ENVIRONMENT ( 1.6, 1.5 OR LATER ) INSTALLED ON YOUR COMPUTER.

For Windows: please download and run the executable installer.

For Linux and MacOs:
- download the zipped installation packadge ( DbSchema.zip )
- unzip it in a local folder and uzip it using the following command from Terminal:
    gunzip DbSchema.zip
- enter the DbSchema folder
    cd DbSchema
- set execution mode to DbSchema script
    chmod +x DbSchema.sh
- start DbSchema
    ./DbSchema.sh

About JDBC drivers
==========================
  DbSchema connects to database using JDBC drivers. This can be done for reading the schema  information,
  browse the database data or execute SQL queries.
  PLEASE DO NOT DISABLE THE NETWORKING FOR DBSCHEMA. THIS MAY GENERATE ERRORS WHEN TRYING TO CONNECT TO DATABASE.
  Please also check your firewall settings.

  JDBC drivers are software files with the extension .jar. Each database uses its own drivers.
  DbSchema includes few database drivers ( MySql, Postgres, Oracle ). If you use another database or if the
  configured driver is too old, you may need to upload the driver file by yourself in the application.
  From application menu 'Tools' -> 'Driver Manager' choose your database and press 'Load driver file' to upload it.
  More information about where you can find the driver files for each database can be found on
  http://www.dbschema.com/drivers.html

Uninstalling DbSchema
==========================
  If you installed DbSchema with the help of Installation Wizard, then
  just run the INSTALLATION_HOME/bin/Uninstall.exe file

  To uninstall DbSchema after manual installation, simply delete the
  contents of the DbSchema home installation directory.


Licensing & pricing
==========================
  Licensing and pricing information can be found at http://www.dbschema.com/purchase.html

Home Page:
==========
  http://www.dbschema.com

Support
=======
  In the DbSchema application you can find an option 'Report a bug' under the tools menu option.
  This is the prefferred method of writing us, since the Java and Windows version as well as the Output logs
  will be sent to us.
  For technical support and assistance, you may find necessary information at the Support page
  (http://www.dbschema.com/support.html) or contact us at support@dbschema.com.

Bug Reporting & Contact:
==============
  Send emails to support@dbschema.com


=============
You are encouraged to visit our DbSchema web site at http://www.dbschema.com
or to contact us via e-mail at support@dbschema.com if you have any comments about
this release. In particular, we are very interested in any ease-of-use, user
interface suggestions that you may have. We will be posting regular updates
of our progress to our online forums.
=============
